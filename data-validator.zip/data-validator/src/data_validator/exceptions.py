class DataValidationError(Exception):
    """Base exception for all domain errors."""

class EmptyFileError(DataValidationError):
    """Raised when the CSV file is 0 bytes or completely empty."""

class MissingHeaderError(DataValidationError):
    """Raised when expected schema headers are missing in the CSV."""

class SchemaConfigError(DataValidationError):
    """Raised when the provided JSON schema is malformed."""