# Data Validator 

A robust Python CLI utility for validating CSV data against a JSON schema. 

## Setup Instructions

1. **Create and activate a virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate